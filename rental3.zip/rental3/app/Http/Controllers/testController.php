<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class testController extends Controller
{
    // untuk form tambah di admin
    public function mobil(Request $request){
        DB::table('mobil')-> insert([
            'jenis_mobil'=>$request->jenis_mobil,
            'tahun'=>$request->tahun,
            'Harga'=>$request->Harga


        ]) ;
        return redirect('/admin');
    }

   public function tambah(){
        
     return view('tambah');
 }

    //=========================================


//untuk form rental
    public function rental($id){
        $mobil = DB::table('mobil')->where('id', $id)->get();
        return view('rental', ['mobil' => $mobil]);
    }


    public function sewa(Request $request){
        DB::table('sewa')->insert([
            'id' => $request->id,
            'jenis_mobil' => $request->jenis_mobil,
            'tahun' => $request->tahun,
            'Harga' => $request->Harga,
            'tanggal_sewa' => $request->tanggal_sewa,
            'tanggal_kembali' => $request->tanggal_kembali
        ]);
    
        return redirect('/utama');
    }
    
//==================================================================


 
//untuk for update atau edit

    public function edit($id){
        $mobil = DB::table('mobil')->where('id', $id)->get();
        return view('edit', ['mobil' => $mobil]);
    }
    
    public function update(Request $request, $id)
    {
        DB::table('mobil')->where('id', $id)->update([
            'jenis_mobil' => $request->jenis_mobil,
            'tahun' => $request->tahun,
            'Harga' => $request->Harga
        ]);
    
        return redirect('/admin');
    }

    //============================================================

    Public function delete($id){
        DB::table('mobil')->where('id',$id) -> delete();
        return redirect('/admin');
    }
    

    public function admin(){
        $mobil = DB::table('mobil')->get();
        return view('admin', ['mobil' => $mobil]);
    }
      

    public function utama(){
        $mobil = DB::table('mobil')->get();
        return view('utama', ['mobil' => $mobil]);
    }

    public function list(){
        $sewa = DB::table('sewa')->get();
        return view('list', ['sewa' => $sewa]);
    }



    public function masuk(){
        
        return view('masuk');
    }
    public function login(){
        
        return view('login');
    }
    public function register(){
        
        return view('register');
    }

    public function profile(){
        
        return view('profile');
    }

    public function contact(){
        
        return view('contact');
    }


    public function hello(){
        
        return view('hello');
    }


   
    
    }
