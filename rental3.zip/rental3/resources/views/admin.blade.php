<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rental Mobil Kalibaru</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-image: url('https://source.unsplash.com/1600x900/?car,rental'); /* Menggunakan gambar latar belakang dari Unsplash */
            background-size: cover;
            background-position: center;
        }

        table {
            border-collapse: collapse;
            width: 60%;
            margin-top: 90px;
            background-color: rgba(255, 255, 255, 0.8); /* Menambahkan transparansi pada tabel */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        a {
            color: #fff;
            text-decoration: none;
            padding: 0.3em 0.8em;
            background-color: #4CAF50;
            border-radius: 5px;
            margin-top: 1em;
            display: inline-block;
        }

        a:hover {
            background-color: #45a049;
        }

        .add-link {
            position: absolute;
            top: 10px;
            right: 10px;
        }
    </style>
</head>
<body>
    <div>
        <a href="/">Home</a>
    </div> 
    <div> 
    <a href="/list">List Rental</a>
    <a href="tambah" class="add-link">Tambah</a>
</div>
    <table>
        <tr>
            <th>ID</th>
            <th>Jenis Mobil</th>
            <th>Tahun</th>
            <th>Harga</th>
            <th>Opsi</th>
        </tr>
        @foreach($mobil as $p)
        <tr>
            <td>{{$p->id}}</td>
            <td>{{$p->jenis_mobil}}</td>
            <td>{{$p->tahun}}</td>
            <td>{{$p->Harga}}</td>
            <td>
                <a href="/edit/{{$p->id}}">Edit</a>
                <a href="/delete/{{$p->id}}">Delete</a>
            </td>
        </tr>
        @endforeach
    </table>
</body>
</html>
