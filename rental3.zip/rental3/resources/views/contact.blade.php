<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 20px 0;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            display: flex;
            justify-content: space-between;
        }

        .contact-info, .contact-form {
            width: 48%;
        }

        .contact-info h2, .contact-form h2 {
            color: #333;
        }

        .contact-info p {
            margin: 5px 0;
        }

        .contact-form form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 10px;
            color: #555;
        }

        input, textarea {
            padding: 10px;
            margin: 5px 0 15px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
    <title>Contact Us - Rental Mobil Kalibaru</title>
</head>
<body>

  <header>
    <h1>Contact Us</h1>
  </header>

  <div class="container">
    <section class="contact-info">
      <h2>Contact Information</h2>
      <p>Email: rental.kalibaru@gmail.com</p>
      <p>Phone: +62 8819590089</p>
      <p>Address: 67 Jln.Malangsari, Kalibaru Kulon, Banyuwangi</p>
    </section>

  </div>

  <footer>
    <p>&copy; 2024 Rental Mobil Kalibaru. All rights reserved.</p>
  </footer>

</body>
</html>
