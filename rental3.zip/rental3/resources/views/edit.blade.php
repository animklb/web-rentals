@foreach($mobil as $p)
<form action="/update/{{$p->id}}" method="post">

    {{ csrf_field() }}

    <input type="hidden" name="id" value="{{$p->id}}"><br/>
  
    <label for="jenis_mobil" > Jenis Mobil: </label>
    <input id="jenis_mobil" type="text" name="jenis_mobil" required="required" value="{{$p->jenis_mobil}}" />
    <label for="tahun" > Tahun: </label>
    <input id="tahun" type="text" name="tahun" required="required" value="{{$p->tahun}}" />
    <label for="Harga" > Harga: </label>  
    <input id="Harga" type="number" name="Harga" required="required" value="{{$p->Harga}}" />
    
    <br/>
 
    <br />
    
    <br/>
    <input type="submit" value="simpan data" >
</form>
@endforeach
<br/>
<a href="/admin">kembali</a>
