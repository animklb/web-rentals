<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rental Mobil Kalibaru</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('https://source.unsplash.com/1600x900/?car,rental');
            background-size: cover;
            background-position: center;
        }

        .navbar {
            background-color: #333;
            padding: 1em 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        }

        .navbar a {
            color: white;
            text-decoration: none;
            padding: 0.5em 1em;
            border-radius: 5px;
            margin-right: 1em;
            transition: background-color 0.3s ease;
        }

        .navbar a:hover {
            background-color: #45a049;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.9);
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        table {
            width: 100%;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        a {
            color: #fff;
            text-decoration: none;
            padding: 0.5em 1em;
            background-color: #4CAF50;
            border-radius: 5px;
            margin-top: 1em;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        a:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <div class="navbar">
        <div>
            <a href="/">Home</a>
        </div>
        <div>
            <a href="utama">utama</a>
            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="{{ route('logout') }}"
                   onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                    {{ __('Logout') }}
                </a>

                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                    @csrf
                </form>
            </div>
            <a href="/contact">Contact</a>
        </div>
    </div>

    <div class="container">
        <h2>Rental Mobil Kalibaru</h2>
        <table>
            <thead>
                <tr>

                    <th>Merek</th>
                    <th>Tahun</th>
                    <th>Harga</th>
                    <th>Tanggal Sewa</th>
                    <th>Tanggal Kembali</th>
                </tr>
            </thead>
            <tbody>
                @foreach($sewa as $p)
                <tr>

                    <td>{{$p->jenis_mobil}}</td>
                    <td>{{$p->tahun}}</td>
                    <td>{{$p->harga}}</td>
                    <td>{{$p->tanggal_sewa}}</td>
                    <td>{{$p->Tanggal_kembali}}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>

</html>
