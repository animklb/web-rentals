<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Rental Mobil Kalibaru</title>
    <style>
        body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    background-image: url('https://img.cintamobil.com/2021/05/31/Yyu6iaT7/bugatti-la-voiture-noire-a11b.jpg');
    background-size: cover; /* Untuk memastikan gambar mengisi seluruh elemen latar belakang */
    background-position: center; /* Posisi gambar di tengah */
}


        form {
            background-color: #fff;
            padding: 2em;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 1em;
        }

        label {
            display: block;
            margin: 1em 0 0.5em;
            color: #333;
        }

        input {
            width: 100%;
            padding: 0.5em;
            margin-bottom: 1em;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        button {
            width: 100%;
            padding: 0.5em;
            background-color: black;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        button:hover {
            background-color: gray;
        }
    </style>
</head>
<body>
    <form>
        <h1>Login</h1>
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <button type="submit">Login</button>
        <a href="register">Register</a>
    </form>
</body>
</html>
