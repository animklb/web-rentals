<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulir Mobil</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        
        form {
            width: 300px;
            margin: 0 auto;
        }
        

        label {
            display: block;
            margin-top: 10px;
        }
        
        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        
        input[type="file"] {
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        
        input[type="submit"] {
            width: 100%;
            padding: 8px;
            margin-top: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        
        input[type="submit"]:hover {
            background-color: #45a049;
        } 
        </style>
</head>
<body>

    <h2>Formulir Penambahan Mobil</h2>

    <form action="/proses_formulir" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
    
        <!-- Input untuk Jenis Mobil -->
        <label for="jenis_mobil">Jenis Mobil:</label>
        <input id="jenis_mobil" type="text" name="jenis_mobil" required="required">
        <br><br>
    
        <!-- Input untuk Tahun Mobil -->
        <label for="tahun">Tahun Mobil:</label>
        <input id="tahun" type="number" name="tahun" min="2000" max="2099" required="required">
        <br><br>

        <label for="Harga">Harga/Hari:</label>
        <input id="Harga" type="number" name="Harga" min="300000" max="5000000" step="50000" required="required">
        <br><br>
    
        <!-- Tombol Submit -->
        <input type="submit" value="Tambah Mobil">
        
        <a href="admin">kembali</a>
    </form>
    

</body>
</html>

