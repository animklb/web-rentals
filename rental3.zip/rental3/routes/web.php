<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});




Route::get('/utama','App\Http\Controllers\testController@utama');
Route::get('/profile','App\Http\Controllers\testController@profile');
Route::get('/hello','App\Http\Controllers\testController@hello');
Route::get('/contact','App\Http\Controllers\testController@contact');
Route::get('/list','App\Http\Controllers\testController@list');
Route::get('/tambah','App\Http\Controllers\testController@tambah');
Route::get('/','App\Http\Controllers\testController@masuk');
Route::get('/login','App\Http\Controllers\testController@login');
Route::get('/register','App\Http\Controllers\testController@register');
Route::get('/rental/{id}', 'App\Http\Controllers\testController@rental');
Route::post('/sewa/{id}', 'App\Http\Controllers\testController@sewa');
Route::get('/admin','App\Http\Controllers\testController@admin');
Route::get('/edit/{id}', 'App\Http\Controllers\testController@edit');
Route::post('/proses_formulir','App\Http\Controllers\testController@mobil');
Route::post('/update/{id}','App\Http\Controllers\testController@update');
Route::get('/delete/{id}', 'App\Http\Controllers\testController@delete');
Route::post('/edit','App\Http\Controllers\testController@mobil');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
