<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <img>
    <title>Rental Mobil Kalibaru</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 1em;
        }

        h1 {
            margin-bottom: 0.5em;
        }

        h3 {
            color: #333;
        }

        a {
            color: #fff;
            text-decoration: none;
            padding: 0.5em 1em;
            background-color: #4CAF50;
            border-radius: 5px;
            margin-top: 1em;
            display: inline-block;
        }

        a:hover {
            background-color: #45a049;
        }

        section {
            max-width: 800px;
            margin: 2em auto;
            padding: 1em;
            background-color: #fff;
            border-radius: 5px;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>RENTAL MOBIL KALIBARU</h1>
        <a href="login">Login</a>
    </header>

    
        <h3>disini peruhaan Kami menyediakan jasa rental mobil lebih tepatnya kami disini menyediakan rental mobil untuk wilayah pulau jawa. kami beralamat di jember, kec. sumbersari, greenland semeru tahap 2 blok K-7 </h3>
            <footer>
                <p>&copy; 2024 Rental Mobil Kalibaru. All rights reserved.</p>
              </footer><?php /**PATH C:\Users\Asus\rental3\resources\views/masuk.blade.php ENDPATH**/ ?>